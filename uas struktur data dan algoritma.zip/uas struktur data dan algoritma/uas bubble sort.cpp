#include <iostream>
#include <string> 
using namespace std;

struct person
{string name;
string address;
    
};

void bubblesort(person people[],int n){
    for (int i = 0; i < n;i++) {
       bool swapped = false;
       for (int j = 0; j < n-i-1; j++){
        if(people[j].name > people[j+1].name){
            swap(people[j], people[j+1]);
            swapped = true;
        }
       }
       if (!swapped) {
        break;
       }
       
    }
}

int main(){
    person people[] = {
        {"Fahmi","Jakarta"},
        {"Romi","Solo"},
        {"Andri","Jakarta"},
        {"Fadillah","Banyuwangi"},
        {"Ruli","Bandung"},
        {"Rudi","Bandung"},
        {"Dendi","Purwokerto"},
        {"Zaki","Madiun"}
    };
    int n = sizeof(people) / sizeof(people[0]);
    cout << "data sebelum di urutkan berdasarkan nama:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "nama: " << people[i].name << ",alamat:" << people[i].address << endl;
    }
    cout << endl;
    bubblesort(people, n);

    cout << "data setelah di urutkan berdasarkan nama:" << endl;
    for(int i = 0; i < n; i++) {
        cout << "nama: " << people[i].name << ",alamat: " << people[i].address << endl;
    }
    cout << endl;

return 0;
    }