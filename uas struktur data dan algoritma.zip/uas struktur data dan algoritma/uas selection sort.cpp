#include <iostream>
#include <string>
using namespace std;

struct person {
    string name;
    string address;
};

void selectionsort(person people[], int n) {
    for(int i=0; i < n-1; i++) {
        int minIndex = i;
        for (int j = i+1; j < n; j++) {
            if (people[j].name < people[minIndex].name) {
                minIndex = j;
            }
        }
        if (minIndex !=i)  {
            swap(people[i], people[minIndex]);
        }
    }
}

int main() {
    person people[]= {
        {"Fahmi", "Jakarta"},
        {"Romi", "solo"},
        {"Andri", "Jakarta"},
        {"Fadillah", "Banyuwangi"},
        {"Ruli", "Bandung"},
        {"Rudi", "Bandung"},
        {"Dendi", "Purwokerto"},
        {"Zaki", "Madiun"}
    };
    int n = sizeof(people) / sizeof(people[0]);
    cout << "data sebelum diurutkan berdasarkan nama: " << endl;
    for (int i = 0; i < n; i++) {
        cout << "nama: " << people[i].name << ", Alamat" << people[i].address << endl;
    } 
    cout << endl;

    selectionsort(people, n);

    cout << "Data setelah di urutkan berdasarkan nama : " << endl;
    for (int i = 0; i < n; i++)  {
        cout << "Nama : " << people[i].name << ", Alamat : " << people[i].address << endl;
    }
cout << endl;
    return 0;
}